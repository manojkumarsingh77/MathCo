SELECT [f.address.city, f.address.state] AS CityState
FROM Families f
