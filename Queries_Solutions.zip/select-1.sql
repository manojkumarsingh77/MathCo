SELECT * 
FROM Families f 
WHERE f.id = "WakefieldFamily"